---
name: bus-arrivals-coruna-data
description: Query A Coruna bus arrivals by stop, bus, or line using iTranvias HTTP API. Use only queryitr_v3.php (func=0 and func=7), never queryitr.php/queryiPhone.php/queryService.php/queryBuilder.php.
---

# Bus Arrivals Coruna Data

Consultar llegadas de cualquier parada y cualquier linea de A Coruna sin preferencias.

## Reglas obligatorias

- Usar siempre HTTPS: `https://itranvias.com`.
- No usar HTTP (`http://`).
- No usar endpoints alternativos (`queryitr.php`, `queryiPhone.php`, `queryService.php`, `queryBuilder.php`, `queryiTransvias.php`, `mo`, `idP`).
- Endpoint valido de llegadas: `https://itranvias.com/queryitr_v3.php?func=0&dato={stop_id}`.
- Endpoint valido de catalogo: `https://itranvias.com/queryitr_v3.php?dato=20160101T000000_gl_0_20160101T000000&func=7`.
- En Claude sandbox, autorizar dominio: `https://itranvias.com`.
- No usar lineas preferidas ni paradas preferidas.
- No intentar endpoints "a ciegas" antes del flujo oficial.
- Los IDs (`parada`, `linea`, `id`) son enteros: comparar siempre como `int`.
- Primera accion obligatoria: ejecutar el comando canonico (abajo) sin pruebas previas.

## Flujo fijo (maximo 2 llamadas)

1. Llamar llegadas por parada (`func=0`).
2. Llamar catalogo (`func=7`) para mapear linea tecnica (`id`) -> nombre comercial (`lin_comer`).
3. Responder con TODAS las lineas presentes en la parada, sin filtrar.

No ejecutar busquedas exploratorias adicionales ni scripts de depuracion salvo que el usuario lo pida.
Ejecutar exactamente el comando canonico de abajo sin modificar su logica.

## Comando canónico (usar este, sin improvisar)

```bash
STOP_ID=100
python3 - "$STOP_ID" <<'PY'
import json
import sys
from urllib.request import Request, urlopen

stop_id = int(sys.argv[1])

CATALOG_URL = "https://itranvias.com/queryitr_v3.php?dato=20160101T000000_gl_0_20160101T000000&func=7"
ARRIVALS_URL = f"https://itranvias.com/queryitr_v3.php?func=0&dato={stop_id}"

HEADERS = {
    "User-Agent": "Mozilla/5.0",
    "Accept": "application/json,text/javascript,*/*;q=0.1",
    "Referer": "https://itranvias.com/",
}

def get_json(url: str) -> dict:
    req = Request(url, headers=HEADERS)
    with urlopen(req, timeout=20) as resp:
        return json.loads(resp.read().decode("utf-8", errors="replace"))

arr = get_json(ARRIVALS_URL)
cat = get_json(CATALOG_URL)

actual = (cat.get("iTranvias") or {}).get("actualizacion") or {}
raw_lines = actual.get("lineas") or []
raw_stops = actual.get("paradas") or []

line_name_by_id = {}
for line in raw_lines:
    if not isinstance(line, dict):
        continue
    try:
        lid = int(line.get("id"))
    except (TypeError, ValueError):
        continue
    line_name_by_id[lid] = str(line.get("lin_comer") or lid)

stop_name_by_id = {}
for stop in raw_stops:
    if not isinstance(stop, dict):
        continue
    try:
        sid = int(stop.get("id"))
    except (TypeError, ValueError):
        continue
    stop_name_by_id[sid] = str(stop.get("nombre") or f"Parada {sid}")

arr_buses = arr.get("buses") or {}
arr_lines = arr_buses.get("lineas") or []

parsed_lines = []
for line in arr_lines:
    if not isinstance(line, dict):
        continue
    try:
        technical_id = int(line.get("linea"))
    except (TypeError, ValueError):
        continue
    buses = []
    for bus in line.get("buses") or []:
        if not isinstance(bus, dict):
            continue
        try:
            bus_id = int(bus.get("bus"))
        except (TypeError, ValueError):
            continue
        try:
            eta = int(bus.get("tiempo"))
        except (TypeError, ValueError):
            eta = None
        try:
            dist = int(bus.get("distancia"))
        except (TypeError, ValueError):
            dist = None
        buses.append({
            "bus_id": bus_id,
            "eta_minutes": eta,
            "distance_meters": dist,
            "status": bus.get("estado"),
            "last_stop_id": bus.get("ult_parada"),
        })
    buses.sort(key=lambda b: 10**9 if b["eta_minutes"] is None else b["eta_minutes"])
    parsed_lines.append({
        "line_technical_id": technical_id,
        "line_name": line_name_by_id.get(technical_id, str(technical_id)),
        "buses": buses,
    })

parsed_lines.sort(key=lambda l: (l["buses"][0]["eta_minutes"] if l["buses"] else 10**9))

output = {
    "ok": True,
    "stop_id": stop_id,
    "stop_name": stop_name_by_id.get(stop_id, f"Parada {stop_id}"),
    "arrivals_url": ARRIVALS_URL,
    "lines": parsed_lines,
}
print(json.dumps(output, ensure_ascii=False, indent=2))
PY
```

## Esquema correcto de respuesta API

- Catalogo:
  - `iTranvias.actualizacion.lineas[]` contiene `id` y `lin_comer`.
  - `iTranvias.actualizacion.paradas[]` contiene `id` y `nombre`.
- Llegadas:
  - `buses.parada`
  - `buses.lineas[]`
- `buses.lineas[].linea` (id tecnico)
- `buses.lineas[].buses[]` con `bus`, `tiempo`, `distancia`, `estado`, `ult_parada`

Importante: no asumir claves `paradas` en raiz ni clave `parada` dentro de catalogo.

## Reglas de salida

- Mostrar nombre comercial de linea cuando exista (`lin_comer`).
- Si no existe, mostrar `linea` tecnica.
- Incluir todas las lineas devueltas en la parada.
- Ordenar lineas por ETA minima de su primer bus.
- Destacar solo las 2 llegadas mas cercanas como resumen.
- Prohibido hardcodear lineas (por ejemplo `300/301/1200/1400`) o listas fijas como `['301','1200','300']`.
- El conjunto de lineas debe salir dinamicamente de `buses.lineas[]` en cada consulta.

## Manejo de errores

- Si `func=0` devuelve 404/HTML/no JSON: reportar error tecnico y no inventar endpoints.
- Si `func=0` devuelve JSON valido con `buses.lineas` vacio: indicar "sin llegadas en este momento".
- Si `stop_id` no existe en `catalogo.paradas[].id`: indicarlo claramente como parada no encontrada.
