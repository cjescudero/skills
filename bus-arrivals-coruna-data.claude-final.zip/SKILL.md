---
name: bus-arrivals-coruna-data
description: Query A Coruna bus arrivals by stop, bus, or line using iTranvias HTTP API.
---

# Bus Arrivals Coruna Data

Resolver llegadas en A Coruna con llamadas HTTP directas al endpoint oficial de iTranvias.

## Reglas obligatorias

- Usar siempre HTTPS: `https://itranvias.com`.
- No usar HTTP (`http://`) porque puede devolver 404 en este servicio.
- No usar endpoints alternativos (`queryService.php`, `queryBuilder.php`, `mo`, `idP`).
- Endpoint valido de llegadas: `queryitr_v3.php?func=0&dato={stop_id}`.
- Endpoint de catalogo (para nombres comerciales): `queryitr_v3.php?dato=20160101T000000_gl_0_20160101T000000&func=7`.
- En Claude sandbox, autorizar dominio: `https://itranvias.com`.

## Flujo de consulta recomendado

1. Obtener catalogo para mapear `linea` tecnica -> nombre comercial (`lin_comer`).
2. Obtener llegadas de la parada con `func=0`.
3. Responder usando nombre comercial de linea siempre que exista.

## Comandos de referencia

```bash
curl -sS "https://itranvias.com/queryitr_v3.php?dato=20160101T000000_gl_0_20160101T000000&func=7"
```

```bash
curl -sS "https://itranvias.com/queryitr_v3.php?func=0&dato=42"
```

## Reglas de salida

- Mostrar linea por nombre comercial (ej. `14`, `3`, `12`, `3A`).
- Si no hay nombre comercial, mostrar ambos: `Línea {linea_tecnica} (sin nombre comercial)`.
- Destacar las 2 llegadas mas cercanas.
- Mantener IDs de bus y minutos ETA.

## Ejemplo de mapeo esperado

- `1400` -> `14`
- `1200` -> `12`
- `300` -> `3`
- `301` -> `3A`
