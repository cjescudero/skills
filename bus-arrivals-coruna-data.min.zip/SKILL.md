---
name: bus-arrivals-coruna-data
description: Query A Coruna bus arrivals by stop, bus, or line using iTranvias HTTP API.
---

# Bus Arrivals Coruna Data

Use the local script first, not manual curl endpoints.

## Commands

```bash
uv run python scripts/query_arrivals.py --stop-id 42 --pretty
```

```bash
uv run python scripts/query_arrivals.py --stop-id 42 --bus-id 3519 --pretty
```

```bash
uv run python scripts/query_arrivals.py --stop-id 42 --line-id 3 --pretty
```

## Notes

- In Claude sandbox, allow `https://itranvias.com` and `http://itranvias.com`.
- Valid arrivals endpoint is `queryitr_v3.php?func=0&dato={stop_id}`.
- Do not use `queryService.php`, `queryBuilder.php`, `mo`, or `idP`.
